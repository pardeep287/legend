/* http://blog.bassta.bg/2013/05/simple-fade-infade-out-slideshow-with-tweenlite/ */

  $(document).ready(function(){
      $(function(){

      var $slidesfirst = $(".slide:first-child"); // Default 
      var $slides = $(".slide");      //slides
      var currentSlide = 1;       //keep track on the current slide
      var stayTime = 3;         //time the slide stays
      var slideTime = 1.3;        //fade in / fade out time
            
        TweenLite.set($slides.filter(":gt(0)"), {autoAlpha:0}); //we hide all images after the first one    
        TweenLite.set($slidesfirst.filter(":gt(0)"), {autoAlpha:1}); //we hide all images after the first one    
        TweenLite.delayedCall(stayTime, nextSlide);       //start the slideshow
            
      function nextSlide(){         
          TweenLite.to( $slides.eq(currentSlide), slideTime, {autoAlpha:0} );   //fade out the old slide
          currentSlide = ++currentSlide % $slides.length;             //find out the next slide     
          TweenLite.to( $slides.eq(currentSlide), slideTime, {autoAlpha:1} );   //fade in the next slide
          TweenLite.delayedCall(stayTime, nextSlide);               //wait a couple of seconds before next slide
      }

    });
  });

	
